Placing `comic.cbz` into this directory and loading `/webslinger/?library=comic.cbz` will pull this comic off the server.
